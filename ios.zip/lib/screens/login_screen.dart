//lib/screens/login_screen.dart
// import 'package:flutter/material.dart';
// import 'signup_screen.dart';
// import 'home_screen.dart'; // Placeholder for next screen after login

// class LoginScreen extends StatefulWidget {
//   const LoginScreen({super.key});

//   @override
//   State<LoginScreen> createState() => _LoginScreenState();
// }

// class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin {
//   final TextEditingController licenseController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();
//   late AnimationController _controller;
//   late Animation<double> _scaleAnim;

//   @override
//   void initState() {
//     super.initState();
//     _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
//     _scaleAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOutBack);
//     _controller.forward();
//   }

//   @override
//   void dispose() {
//     _controller.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final theme = Theme.of(context);
//     return Scaffold(
//       body: Center(
//         child: ScaleTransition(
//           scale: _scaleAnim,
//           child: Container(
//             padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
//             constraints: const BoxConstraints(maxWidth: 400),
//             decoration: BoxDecoration(
//               color: theme.cardColor.withOpacity(0.85),
//               borderRadius: BorderRadius.circular(28),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.18),
//                   blurRadius: 32,
//                   offset: const Offset(0, 12),
//                 ),
//               ],
//               border: Border.all(color: Colors.white.withOpacity(0.04), width: 1.5),
//             ),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 CircleAvatar(
//                   radius: 36,
//                   backgroundColor: theme.colorScheme.primary.withOpacity(0.12),
//                   child: Icon(Icons.medical_services_rounded, color: theme.colorScheme.primary, size: 38),
//                 ),
//                 const SizedBox(height: 18),
//                 Text("Welcome Back!", style: theme.textTheme.headlineMedium),
//                 const SizedBox(height: 6),
//                 Text("Login to your account", style: theme.textTheme.bodyLarge?.copyWith(color: Colors.white70)),
//                 const SizedBox(height: 32),
//                 TextField(
//                   controller: licenseController,
//                   style: const TextStyle(color: Colors.white),
//                   decoration: InputDecoration(
//                     labelText: 'License Number',
//                     prefixIcon: const Icon(Icons.badge_rounded),
//                   ),
//                 ),
//                 const SizedBox(height: 20),
//                 TextField(
//                   controller: passwordController,
//                   obscureText: true,
//                   style: const TextStyle(color: Colors.white),
//                   decoration: InputDecoration(
//                     labelText: 'Password',
//                     prefixIcon: const Icon(Icons.lock_rounded),
//                   ),
//                 ),
//                 const SizedBox(height: 30),
//                 SizedBox(
//                   width: double.infinity,
//                   child: ElevatedButton.icon(
//                     icon: const Icon(Icons.login_rounded),
//                     label: const Text('LOG IN'),
//                     onPressed: () {
//                       Navigator.push(
//                         context,
//                         MaterialPageRoute(builder: (context) => const HomeScreen()),
//                       );
//                     },
//                     style: ElevatedButton.styleFrom(
//                       padding: const EdgeInsets.symmetric(vertical: 16),
//                       textStyle: const TextStyle(fontSize: 18),
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 18),
//                 GestureDetector(
//                   onTap: () {
//                     Navigator.push(
//                       context,
//                       MaterialPageRoute(builder: (context) => const SignupScreen()),
//                     );
//                   },
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       const Icon(Icons.person_add_alt_1_rounded, color: Colors.white54, size: 20),
//                       const SizedBox(width: 8),
//                       Text(
//                         "Don't have an account? ",
//                         style: theme.textTheme.bodyLarge?.copyWith(color: Colors.white54),
//                       ),
//                       Text(
//                         "Sign Up",
//                         style: theme.textTheme.bodyLarge?.copyWith(
//                           color: theme.colorScheme.primary,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }


//final up



// import 'package:flutter/material.dart';
// import 'signup_screen.dart';
// import 'home_screen.dart';
// import 'package:http/http.dart' as http;
// import 'dart:convert';

// class LoginScreen extends StatefulWidget {
//   const LoginScreen({super.key});

//   @override
//   State<LoginScreen> createState() => _LoginScreenState();
// }

// class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin {
//   final TextEditingController licenseController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();
//   late AnimationController _controller;
//   late Animation<double> _scaleAnim;

//   @override
//   void initState() {
//     super.initState();
//     _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
//     _scaleAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOutBack);
//     _controller.forward();
//   }

//   @override
//   void dispose() {
//     _controller.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     final theme = Theme.of(context);
//     return Scaffold(
//       body: Center(
//         child: ScaleTransition(
//           scale: _scaleAnim,
//           child: Container(
//             padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
//             constraints: const BoxConstraints(maxWidth: 400),
//             decoration: BoxDecoration(
//               color: theme.cardColor.withOpacity(0.85),
//               borderRadius: BorderRadius.circular(28),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.18),
//                   blurRadius: 32,
//                   offset: const Offset(0, 12),
//                 ),
//               ],
//               border: Border.all(color: Colors.white.withOpacity(0.04), width: 1.5),
//             ),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 CircleAvatar(
//                   radius: 36,
//                   backgroundColor: theme.colorScheme.primary.withOpacity(0.12),
//                   child: Icon(Icons.medical_services_rounded, color: theme.colorScheme.primary, size: 38),
//                 ),
//                 const SizedBox(height: 18),
//                 Text("Welcome Back!", style: theme.textTheme.headlineMedium),
//                 const SizedBox(height: 6),
//                 Text("Login to your account", style: theme.textTheme.bodyLarge?.copyWith(color: Colors.white70)),
//                 const SizedBox(height: 32),
//                 TextField(
//                   controller: licenseController,
//                   style: const TextStyle(color: Colors.white),
//                   decoration: InputDecoration(
//                     labelText: 'License Number',
//                     prefixIcon: const Icon(Icons.badge_rounded),
//                   ),
//                 ),
//                 const SizedBox(height: 20),
//                 TextField(
//                   controller: passwordController,
//                   obscureText: true,
//                   style: const TextStyle(color: Colors.white),
//                   decoration: InputDecoration(
//                     labelText: 'Password',
//                     prefixIcon: const Icon(Icons.lock_rounded),
//                   ),
//                 ),
//                 const SizedBox(height: 30),
//                 SizedBox(
//                   width: double.infinity,
//                   child: ElevatedButton.icon(
//                     icon: const Icon(Icons.login_rounded),
//                     label: const Text('LOG IN'),
//                     onPressed: () async {
//                       final license = licenseController.text.trim();
//                       final password = passwordController.text;

//                       final url = Uri.parse('http://192.168.206.67:5000/api/auth/login');

//                       try {
//                         final response = await http.post(
//                           url,
//                           headers: {"Content-Type": "application/json"},
//                           body: jsonEncode({
//                             'licenseNumber': license,
//                             'password': password,
//                           }),
//                         );

//                         final data = jsonDecode(response.body);

//                         if (response.statusCode == 200) {
//                           ScaffoldMessenger.of(context).showSnackBar(
//                             SnackBar(content: Text(data['message'])),
//                           );
//                           Navigator.pushReplacement(
//                             context,
//                             MaterialPageRoute(builder: (context) => const HomeScreen()),
//                           );
//                         } else {
//                           ScaffoldMessenger.of(context).showSnackBar(
//                             SnackBar(content: Text(data['message'] ?? 'Login failed')),
//                           );
//                         }
//                       } catch (e) {
//                         ScaffoldMessenger.of(context).showSnackBar(
//                           SnackBar(content: Text("Error: $e")),
//                         );
//                       }
//                     },
//                     style: ElevatedButton.styleFrom(
//                       padding: const EdgeInsets.symmetric(vertical: 16),
//                       textStyle: const TextStyle(fontSize: 18),
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 18),
//                 GestureDetector(
//                   onTap: () {
//                     Navigator.push(
//                       context,
//                       MaterialPageRoute(builder: (context) => const SignupScreen()),
//                     );
//                   },
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       const Icon(Icons.person_add_alt_1_rounded, color: Colors.white54, size: 20),
//                       const SizedBox(width: 8),
//                       Text(
//                         "Don't have an account? ",
//                         style: theme.textTheme.bodyLarge?.copyWith(color: Colors.white54),
//                       ),
//                       Text(
//                         "Sign Up",
//                         style: theme.textTheme.bodyLarge?.copyWith(
//                           color: theme.colorScheme.primary,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'signup_screen.dart';
// import 'home_screen.dart';
// import 'package:http/http.dart' as http;
// import 'dart:convert';
// import 'package:shared_preferences/shared_preferences.dart';

// class LoginScreen extends StatefulWidget {
//   const LoginScreen({super.key});

//   @override
//   State<LoginScreen> createState() => _LoginScreenState();
// }

// class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin {
//   final TextEditingController licenseController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();
//   late AnimationController _controller;
//   late Animation<double> _scaleAnim;

//   @override
//   void initState() {
//     super.initState();
//     _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
//     _scaleAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOutBack);
//     _controller.forward();
//   }

//   @override
//   void dispose() {
//     _controller.dispose();
//     super.dispose();
//   }

//   Future<void> loginUser() async {
//     final license = licenseController.text.trim();
//     final password = passwordController.text;
//     final url = Uri.parse('http://192.168.206.67:5000/api/auth/login');

//     try {
//       final response = await http.post(
//         url,
//         headers: {"Content-Type": "application/json"},
//         body: jsonEncode({
//           'licenseNumber': license,
//           'password': password,
//         }),
//       );

//       final data = jsonDecode(response.body);

//       if (response.statusCode == 200) {
//         final prefs = await SharedPreferences.getInstance();
//         await prefs.setString('licenseNumber', data['user']['licenseNumber']);
//         await prefs.setString('email', data['user']['email'] ?? '');
//         await prefs.setString('hospital', data['user']['hospital'] ?? '');
//         await prefs.setString('name', data['user']['name'] ?? '');

//         ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'])));
//         Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const HomeScreen()));
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(data['message'] ?? 'Login failed')));
//       }
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     final theme = Theme.of(context);
//     return Scaffold(
//       body: Center(
//         child: ScaleTransition(
//           scale: _scaleAnim,
//           child: Container(
//             padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
//             constraints: const BoxConstraints(maxWidth: 400),
//             decoration: BoxDecoration(
//               color: theme.cardColor.withOpacity(0.85),
//               borderRadius: BorderRadius.circular(28),
//               boxShadow: [
//                 BoxShadow(color: Colors.black.withOpacity(0.18), blurRadius: 32, offset: const Offset(0, 12)),
//               ],
//               border: Border.all(color: Colors.white.withOpacity(0.04), width: 1.5),
//             ),
//             child: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: [
//                 CircleAvatar(
//                   radius: 36,
//                   backgroundColor: theme.colorScheme.primary.withOpacity(0.12),
//                   child: Icon(Icons.medical_services_rounded, color: theme.colorScheme.primary, size: 38),
//                 ),
//                 const SizedBox(height: 18),
//                 Text("Welcome Back!", style: theme.textTheme.headlineMedium),
//                 const SizedBox(height: 6),
//                 Text("Login to your account", style: theme.textTheme.bodyLarge?.copyWith(color: Colors.white70)),
//                 const SizedBox(height: 32),
//                 TextField(
//                   controller: licenseController,
//                   style: const TextStyle(color: Colors.white),
//                   decoration: const InputDecoration(
//                     labelText: 'License Number',
//                     prefixIcon: Icon(Icons.badge_rounded),
//                   ),
//                 ),
//                 const SizedBox(height: 20),
//                 TextField(
//                   controller: passwordController,
//                   obscureText: true,
//                   style: const TextStyle(color: Colors.white),
//                   decoration: const InputDecoration(
//                     labelText: 'Password',
//                     prefixIcon: Icon(Icons.lock_rounded),
//                   ),
//                 ),
//                 const SizedBox(height: 30),
//                 SizedBox(
//                   width: double.infinity,
//                   child: ElevatedButton.icon(
//                     icon: const Icon(Icons.login_rounded),
//                     label: const Text('LOG IN'),
//                     onPressed: loginUser,
//                     style: ElevatedButton.styleFrom(
//                       padding: const EdgeInsets.symmetric(vertical: 16),
//                       textStyle: const TextStyle(fontSize: 18),
//                     ),
//                   ),
//                 ),
//                 const SizedBox(height: 18),
//                 GestureDetector(
//                   onTap: () {
//                     Navigator.push(
//                       context,
//                       MaterialPageRoute(builder: (context) => const SignupScreen()),
//                     );
//                   },
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       const Icon(Icons.person_add_alt_1_rounded, color: Colors.white54, size: 20),
//                       const SizedBox(width: 8),
//                       Text("Don't have an account? ", style: theme.textTheme.bodyLarge?.copyWith(color: Colors.white54)),
//                       Text("Sign Up", style: theme.textTheme.bodyLarge?.copyWith(color: theme.colorScheme.primary, fontWeight: FontWeight.bold)),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }


import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'signup_screen.dart';
import 'home_screen.dart'; // Placeholder for your actual home screen

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin {
  final TextEditingController licenseController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  late AnimationController _controller;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _scaleAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOutBack);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final license = licenseController.text.trim();
    final password = passwordController.text;

    if (license.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please fill all fields")));
      return;
    }

    final response = await http.post(
      Uri.parse('http://192.168.122.67:5000/api/auth/login'), // Replace with your IP
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'licenseNumber': license, 'password': password}),
    );

    if (response.statusCode == 200) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const HomeScreen()));
    } else {
      final message = jsonDecode(response.body)['message'];
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: Center(
        child: ScaleTransition(
          scale: _scaleAnim,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
            constraints: const BoxConstraints(maxWidth: 400),
            decoration: BoxDecoration(
              color: theme.cardColor.withOpacity(0.85),
              borderRadius: BorderRadius.circular(28),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.18),
                  blurRadius: 32,
                  offset: const Offset(0, 12),
                ),
              ],
              border: Border.all(color: Colors.white.withOpacity(0.04), width: 1.5),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircleAvatar(
                  radius: 36,
                  backgroundColor: theme.colorScheme.primary.withOpacity(0.12),
                  child: Icon(Icons.medical_services_rounded, color: theme.colorScheme.primary, size: 38),
                ),
                const SizedBox(height: 18),
                Text("Welcome Back!", style: theme.textTheme.headlineMedium),
                const SizedBox(height: 6),
                Text("Login to your account", style: theme.textTheme.bodyLarge?.copyWith(color: Colors.white70)),
                const SizedBox(height: 32),
                TextField(
                  controller: licenseController,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'License Number',
                    prefixIcon: const Icon(Icons.badge_rounded),
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: passwordController,
                  obscureText: true,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Password',
                    prefixIcon: const Icon(Icons.lock_rounded),
                  ),
                ),
                const SizedBox(height: 30),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.login_rounded),
                    label: const Text('LOG IN'),
                    onPressed: _login,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      textStyle: const TextStyle(fontSize: 18),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                GestureDetector(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => const SignupScreen()));
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.person_add_alt_1_rounded, color: Colors.white54, size: 20),
                      const SizedBox(width: 8),
                      Text("Don't have an account? ",
                          style: theme.textTheme.bodyLarge?.copyWith(color: Colors.white54)),
                      Text("Sign Up",
                          style: theme.textTheme.bodyLarge?.copyWith(
                            color: theme.colorScheme.primary,
                            fontWeight: FontWeight.bold,
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
