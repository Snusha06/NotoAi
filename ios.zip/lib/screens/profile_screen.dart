import 'package:flutter/material.dart';
// import 'home_screen.dart';

// class ProfileScreen extends StatelessWidget {
//   const ProfileScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     final theme = Theme.of(context);
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Profile'),
//         centerTitle: true,
//         actions: [
//           IconButton(
//             icon: const Icon(Icons.edit_rounded),
//             tooltip: 'Edit Profile',
//             onPressed: () {
//               // TODO: Implement actual edit profile functionality
//               ScaffoldMessenger.of(context).showSnackBar(
//                 const SnackBar(content: Text('Edit Profile tapped!')),
//               );
//             },
//           ),
//         ],
//       ),
//       body: SafeArea(
//         child: SingleChildScrollView(
//           padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.start,
//             children: [
//               const SizedBox(height: 16),
//               CircleAvatar(
//                 radius: 48,
//                 backgroundColor: theme.colorScheme.primary.withOpacity(0.15),
//                 child: const Icon(Icons.person, size: 54, color: Colors.white),
//               ),
//               const SizedBox(height: 18),
//               Text('Dr. XYZ', style: theme.textTheme.headlineMedium),
//               const SizedBox(height: 6),
//               Text('Cardiologist', style: theme.textTheme.bodyLarge?.copyWith(color: Colors.white70)),
//               const SizedBox(height: 24),
//               Card(
//                 elevation: 3,
//                 shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
//                 child: Padding(
//                   padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Row(
//                         children: const [
//                           Icon(Icons.badge_rounded, color: Colors.white54),
//                           SizedBox(width: 10),
//                           Text('License: 123456', style: TextStyle(color: Colors.white)),
//                         ],
//                       ),
//                       const SizedBox(height: 12),
//                       Row(
//                         children: const [
//                           Icon(Icons.local_hospital_rounded, color: Colors.white54),
//                           SizedBox(width: 10),
//                           Text('Hospital: ABC Hospital', style: TextStyle(color: Colors.white)),
//                         ],
//                       ),
//                       const SizedBox(height: 12),
//                       Row(
//                         children: const [
//                           Icon(Icons.email_rounded, color: Colors.white54),
//                           SizedBox(width: 10),
//                           Text('Email: xyz@email.com', style: TextStyle(color: Colors.white)),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//               const SizedBox(height: 32),
//               SizedBox(
//                 width: double.infinity,
//                 child: ElevatedButton.icon(
//                   icon: const Icon(Icons.logout_rounded),
//                   label: const Text('LOG OUT'),
//                   onPressed: () {
//                     // TODO: Implement actual logout logic (clear session, etc.)
//                     Navigator.pushNamedAndRemoveUntil(
//                       context,
//                       '/login', // Assuming your login route is '/login'
//                       (Route<dynamic> route) => false,
//                     );
//                   },
//                   style: ElevatedButton.styleFrom(
//                     padding: const EdgeInsets.symmetric(vertical: 16),
//                     backgroundColor: Colors.redAccent,
//                     foregroundColor: Colors.white,
//                     textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
//                     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//       bottomNavigationBar: const BottomNavBar(currentIndex: 3),
//     );
//   }
// }


// import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'login_screen.dart';
import 'home_screen.dart'; // Assuming BottomNavBar is in home_screen.dart

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String name = '';
  String hospital = '';
  String email = '';
  String licenseNumber = '';
  String specialization = '';

  @override
  void initState() {
    super.initState();
    loadProfileData();
  }

  Future<void> loadProfileData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      name = prefs.getString('name') ?? 'Dr. John Doe';
      hospital = prefs.getString('hospital') ?? 'ABC Hospital';
      email = prefs.getString('email') ?? 'johndoe@email.com';
      licenseNumber = prefs.getString('licenseNumber') ?? '123456';
      specialization = prefs.getString('specialization') ?? 'Cardiologist';
    });
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const LoginScreen()),
      (route) => false,
    );
  }

  Future<void> _editProfile() async {
    String newName = name;
    String newHospital = hospital;
    String newEmail = email;
    String newSpecialization = specialization;

    await showDialog(context: context, builder: (context) {
      return AlertDialog(
        title: const Text('Edit Profile'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: InputDecoration(labelText: 'Name'),
                onChanged: (value) => newName = value,
                controller: TextEditingController(text: name),
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Specialization'),
                onChanged: (value) => newSpecialization = value,
                controller: TextEditingController(text: specialization),
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Hospital'),
                onChanged: (value) => newHospital = value,
                controller: TextEditingController(text: hospital),
              ),
              TextField(
                decoration: InputDecoration(labelText: 'Email'),
                onChanged: (value) => newEmail = value,
                controller: TextEditingController(text: email),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.setString('name', newName);
              await prefs.setString('specialization', newSpecialization);
              await prefs.setString('hospital', newHospital);
              await prefs.setString('email', newEmail);

              Navigator.pop(context);
              loadProfileData();
            },
            child: const Text('Save'),
          ),
        ],
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text("Profile"),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_rounded),
            onPressed: _editProfile,
            tooltip: 'Edit Profile',
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 16),
              CircleAvatar(
                radius: 48,
                backgroundColor: theme.colorScheme.primary.withOpacity(0.15),
                child: const Icon(Icons.person, size: 54, color: Colors.white),
              ),
              const SizedBox(height: 18),
              Text(name, style: theme.textTheme.headlineMedium?.copyWith(color: Colors.white)),
              const SizedBox(height: 6),
              Text(specialization, style: theme.textTheme.bodyLarge?.copyWith(color: Colors.white70)),
              const SizedBox(height: 24),
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                margin: const EdgeInsets.symmetric(horizontal: 0),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.badge_rounded, color: Colors.white54),
                          SizedBox(width: 10),
                          Text('License: $licenseNumber', style: TextStyle(color: Colors.white, fontSize: 16)),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Icon(Icons.local_hospital_rounded, color: Colors.white54),
                          SizedBox(width: 10),
                          Text('Hospital: $hospital', style: TextStyle(color: Colors.white, fontSize: 16)),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Icon(Icons.email_rounded, color: Colors.white54),
                          SizedBox(width: 10),
                          Text('Email: $email', style: TextStyle(color: Colors.white, fontSize: 16)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.logout_rounded),
                  label: const Text('LOG OUT'),
                  onPressed: logout,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    backgroundColor: Colors.redAccent,
                    foregroundColor: Colors.white,
                    textStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: const BottomNavBar(currentIndex: 3),
    );
  }
}
