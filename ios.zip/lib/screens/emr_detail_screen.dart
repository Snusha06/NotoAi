import 'package:flutter/material.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class EMRDetailScreen extends StatelessWidget {
  final Map<String, dynamic> emr;
  const EMRDetailScreen({super.key, required this.emr});

  Future<pw.Document> _buildPdf() async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) => pw.Container(
          padding: const pw.EdgeInsets.all(24),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Center(
                child: pw.Text('HOSPITAL NAME', style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
              ),
              pw.SizedBox(height: 24),
              pw.Text(emr['emrData']?['rawText'] ?? ''),
              pw.Spacer(),
              pw.SizedBox(height: 24),
              pw.Text('Signature:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
    return pdf;
  }

  Future<void> _exportPdf(BuildContext context) async {
    final pdf = await _buildPdf();
    await Printing.sharePdf(bytes: await pdf.save(), filename: 'emr.pdf');
  }

  Future<void> _printPdf(BuildContext context) async {
    final pdf = await _buildPdf();
    await Printing.layoutPdf(onLayout: (format) => pdf.save());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('EMR Detail'),
        actions: [
          IconButton(
            icon: const Icon(Icons.picture_as_pdf),
            tooltip: 'Export as PDF',
            onPressed: () => _exportPdf(context),
          ),
          IconButton(
            icon: const Icon(Icons.print),
            tooltip: 'Print',
            onPressed: () => _printPdf(context),
          ),
        ],
      ),
      body: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 500),
          padding: const EdgeInsets.all(24),
          margin: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 8,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Text(
                  emr['emrData']?['hospitalName'] ?? '',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 24),
              Expanded(
                child: SingleChildScrollView(
                  child: Text(
                    emr['emrData']?['rawText'] ?? '',
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: Colors.black87),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              const Text('Signature:', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
} 