import 'package:flutter/material.dart';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as path;
import 'dart:convert';
import 'home_screen.dart';
import 'package:google_ml_kit/google_ml_kit.dart';
import 'package:image/image.dart' as img;
import 'package:google_mlkit_commons/google_mlkit_commons.dart';

class PreviewScreen extends StatefulWidget {
  const PreviewScreen({super.key});

  @override
  State<PreviewScreen> createState() => _PreviewScreenState();
}

class _PreviewScreenState extends State<PreviewScreen> {
  bool _loading = false;
  Map<String, dynamic>? _emrResult;
  String? _error;

  Future<void> _convertToEMR(String? imagePath, String? imageUrl) async {
    setState(() {
      _loading = true;
      _error = null;
      _emrResult = null;
    });
    try {
      if (imagePath == null && imageUrl == null) {
        setState(() {
          _error = 'No image selected.';
        });
        return;
      }
      InputImage inputImage;
      if (imagePath != null) {
        inputImage = InputImage.fromFilePath(imagePath);
      } else {
        // For web, fetch the image as bytes and upload
        final response = await http.get(Uri.parse(imageUrl!));
        final imageBytes = response.bodyBytes;
        final decodedImage = img.decodeImage(imageBytes);
        if (decodedImage == null) throw Exception('Failed to decode image');
        inputImage = InputImage.fromBytes(
          bytes: imageBytes,
          metadata: InputImageMetadata(
            size: Size(decodedImage.width.toDouble(), decodedImage.height.toDouble()),
            rotation: InputImageRotation.rotation0deg,
            format: InputImageFormat.bgra8888, // Most common for web
            bytesPerRow: decodedImage.width * 4,
          ),
        );
      }
      final textRecognizer = GoogleMlKit.vision.textRecognizer();
      final RecognizedText recognizedText = await textRecognizer.processImage(inputImage);
      await textRecognizer.close();
      final text = recognizedText.text;
      final emrData = _parseEMR(text);
      setState(() {
        _emrResult = emrData;
      });
      // Automatically save to backend
      await _saveEMRToBackend(emrData['rawText'] ?? '');
    } catch (e) {
      setState(() {
        _error = 'Error: $e';
      });
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  Map<String, dynamic> _parseEMR(String text) {
    // Only store and return the raw OCR text
    return {
      'rawText': text,
    };
  }

  Future<void> _saveEMRToBackend(String rawText) async {
    try {
      final response = await http.post(
        Uri.parse('http://192.168.122.67:5000/emrs'), // Update to your backend endpoint
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'rawText': rawText}),
      );
      if (response.statusCode == 200 || response.statusCode == 201) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('EMR saved!'), duration: Duration(seconds: 2)),
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Failed to save EMR: ${response.statusCode}'), duration: const Duration(seconds: 2)),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving EMR: $e'), duration: const Duration(seconds: 2)),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final Object? arg = ModalRoute.of(context)?.settings.arguments;
    String? imagePath;
    String? imageUrl;
    if (kIsWeb) {
      imageUrl = arg as String?;
    } else {
      imagePath = arg as String?;
    }
    return Scaffold(
      backgroundColor: const Color(0xFF06141B),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 40),
              const Text("PREVIEW", style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, letterSpacing: 1, color: Color(0xFFCCD0CF))),
              const SizedBox(height: 24),
              Card(
                elevation: 6,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                color: const Color(0xFF11212D),
                child: Container(
                  width: 260,
                  height: 340,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    color: const Color(0xFF11212D),
                  ),
                  child: kIsWeb
                      ? (imageUrl != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(18),
                              child: Image.network(imageUrl, fit: BoxFit.cover),
                            )
                          : const Center(child: Text("DOCUMENT", style: TextStyle(color: Color(0xFF9BA8AB)))))
                      : (imagePath != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(18),
                              child: Image.file(File(imagePath), fit: BoxFit.cover),
                            )
                          : const Center(child: Text("DOCUMENT", style: TextStyle(color: Color(0xFF9BA8AB))))),
                ),
              ),
              const SizedBox(height: 24),
              if (_loading) const CircularProgressIndicator(),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(_error!, style: const TextStyle(color: Colors.red, fontSize: 15)),
                ),
              if (_emrResult != null) ...[
                const SizedBox(height: 18),
                Card(
                  elevation: 3,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  color: const Color(0xFF11212D),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Raw OCR:', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF4A5C6A))),
                        Text(_emrResult?['rawText'] ?? '', style: const TextStyle(fontSize: 15, color: Color(0xFFCCD0CF))),
                      ],
                    ),
                  ),
                ),
              ],
              if (!_loading && _emrResult == null && (imagePath != null || imageUrl != null))
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 18.0, horizontal: 40),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => _convertToEMR(imagePath, imageUrl),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF2563EB),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      child: const Text("Convert to EMR"),
                    ),
                  ),
                ),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
      bottomNavigationBar: const BottomNavBar(currentIndex: 2),
    );
  }
}
