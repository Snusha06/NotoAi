import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'home_screen.dart';
import 'emr_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  List<dynamic> _emrs = [];
  List<dynamic> _filteredEmrs = [];
  bool _loading = true;
  String? _error;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchEMRs().then((_) {
      _searchController.addListener(_filterEMRs);
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _fetchEMRs() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final response = await http.get(Uri.parse('http://192.168.122.67:5000/emrs'));
      if (response.statusCode == 200) {
        setState(() {
          _emrs = json.decode(response.body);
          _filteredEmrs = _emrs;
        });
      } else {
        setState(() {
          _error = 'Failed to fetch EMRs (${response.statusCode})';
          _filteredEmrs = [];
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Error: $e';
        _filteredEmrs = [];
      });
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  void _filterEMRs() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        _filteredEmrs = _emrs;
      } else {
        _filteredEmrs = _emrs.where((emr) {
          final rawText = emr['emrData']?['rawText']?.toLowerCase() ?? '';
          return rawText.contains(query);
        }).toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: theme.colorScheme.background,
      body: Column(
        children: [
          const SizedBox(height: 50),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: "Search EMR records",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide(color: theme.colorScheme.primary, width: 1.5),
                ),
                prefixIcon: Icon(Icons.search, color: theme.colorScheme.primary),
                contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                filled: true,
                fillColor: theme.cardColor,
              ),
              style: TextStyle(color: theme.colorScheme.onBackground),
              cursorColor: theme.colorScheme.primary,
              enabled: true,
            ),
          ),
          if (_loading)
            const Padding(
              padding: EdgeInsets.all(20),
              child: CircularProgressIndicator(),
            ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.all(20),
              child: Text(_error!, style: const TextStyle(color: Colors.red)),
            ),
          if (!_loading && _filteredEmrs.isNotEmpty)
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                itemCount: _filteredEmrs.length,
                itemBuilder: (context, index) {
                  final emr = _filteredEmrs[index];
                  final rawText = emr['emrData']?['rawText'] ?? '';
                  final previewText = rawText.length > 120 ? rawText.substring(0, 120) + '...' : rawText;
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 10),
                    elevation: 4,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    color: theme.cardColor,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => EMRDetailScreen(emr: emr),
                          ),
                        );
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Prescription OCR',
                              style: theme.textTheme.titleMedium,
                            ),
                            const SizedBox(height: 10),
                            Text(
                              previewText,
                              style: theme.textTheme.bodyLarge?.copyWith(color: theme.colorScheme.onBackground),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          if (!_loading && _filteredEmrs.isEmpty && _searchController.text.isNotEmpty)
            const Padding(
              padding: EdgeInsets.all(20),
              child: Text('No matching EMRs found.'),
            ) else if (!_loading && _filteredEmrs.isEmpty && _searchController.text.isEmpty)
             const Padding(
              padding: EdgeInsets.all(20),
              child: Text('No EMRs found.'),
            ),
        ],
      ),
      bottomNavigationBar: const BottomNavBar(currentIndex: 1),
    );
  }
}
