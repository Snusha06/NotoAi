// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:flutter_secure_storage/flutter_secure_storage.dart';

// class AuthService {
//   static const _baseUrl = 'http://<YOUR_IP>:5000/api/auth'; // Replace <YOUR_IP>

//   static final storage = FlutterSecureStorage();

//   static Future<String?> signUp(String license, String password) async {
//     final response = await http.post(
//       Uri.parse('$_baseUrl/signup'),
//       headers: {'Content-Type': 'application/json'},
//       body: jsonEncode({'licenseNumber': license, 'password': password}),
//     );

//     if (response.statusCode == 201) {
//       return null; // Success
//     } else {
//       return jsonDecode(response.body)['message'];
//     }
//   }

//   static Future<String?> login(String license, String password) async {
//     final response = await http.post(
//       Uri.parse('$_baseUrl/login'),
//       headers: {'Content-Type': 'application/json'},
//       body: jsonEncode({'licenseNumber': license, 'password': password}),
//     );

//     if (response.statusCode == 200) {
//       final token = jsonDecode(response.body)['token'];
//       await storage.write(key: 'token', value: token);
//       return null;
//     } else {
//       return jsonDecode(response.body)['message'];
//     }
//   }

//   static Future<void> logout() async {
//     await storage.delete(key: 'token');
//   }

//   static Future<String?> getToken() async {
//     return await storage.read(key: 'token');
//   }
// }
import 'dart:convert';
import 'package:http/http.dart' as http;

class AuthService {
  static const String baseUrl = 'http://<YOUR_IP>:5000/api/auth'; // Replace <YOUR_IP>

  static Future<String?> signUp(String licenseNumber, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/signup'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'licenseNumber': licenseNumber, 'password': password}),
      );

      if (response.statusCode == 201) {
        return null; // Success
      } else {
        final data = jsonDecode(response.body);
        return data['message'] ?? 'Unknown error occurred.';
      }
    } catch (e) {
      return 'Network error: $e';
    }
  }
}
