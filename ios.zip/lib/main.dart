import 'package:flutter/material.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/home_screen.dart';
import 'screens/search_screen.dart';
import 'screens/preview_screen.dart';
import 'screens/profile_screen.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Custom color palette
    const Color background = Color(0xFF06141B); // main background
    const Color card = Color(0xFF11212D); // card background
    const Color surface = Color(0xFF253745); // surface/secondary card
    const Color accent = Color(0xFF4A5C6A); // accent/secondary
    const Color textPrimary = Color(0xFFCCD0CF); // main text
    const Color textSecondary = Color(0xFF9BA8AB); // secondary text
    const Color blueAccent = Color(0xFF2563EB); // keep for buttons/icons

    return MaterialApp(
      title: 'AI EMR App',
      theme: ThemeData(
        colorScheme: ColorScheme.dark(
          primary: blueAccent,
          secondary: accent,
          background: background,
          surface: surface,
        ),
        scaffoldBackgroundColor: background,
        cardColor: card,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        textTheme: GoogleFonts.poppinsTextTheme(ThemeData.dark().textTheme).copyWith(
          headlineLarge: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 32, color: textPrimary),
          headlineMedium: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 24, color: textPrimary),
          headlineSmall: GoogleFonts.poppins(fontWeight: FontWeight.w600, fontSize: 20, color: textPrimary),
          titleMedium: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 18, color: textPrimary),
          bodyLarge: GoogleFonts.poppins(fontSize: 16, color: textSecondary),
          bodyMedium: GoogleFonts.poppins(fontSize: 14, color: textSecondary),
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: background,
          foregroundColor: textPrimary,
          elevation: 0,
          iconTheme: const IconThemeData(color: textPrimary),
          titleTextStyle: GoogleFonts.poppins(
            color: textPrimary,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
          filled: true,
          fillColor: card,
          prefixIconColor: blueAccent,
          labelStyle: GoogleFonts.poppins(color: textSecondary),
          hintStyle: GoogleFonts.poppins(color: textSecondary.withOpacity(0.7)),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: blueAccent,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            textStyle: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 18),
            elevation: 2,
            shadowColor: blueAccent.withOpacity(0.2),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: blueAccent,
            side: BorderSide(color: blueAccent, width: 2),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            textStyle: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 18),
          ),
        ),
        iconTheme: const IconThemeData(color: blueAccent, size: 28),
        cardTheme: CardTheme(
          color: card,
          elevation: 4,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        bottomNavigationBarTheme: BottomNavigationBarThemeData(
          backgroundColor: card,
          selectedItemColor: blueAccent,
          unselectedItemColor: textSecondary,
          showSelectedLabels: false,
          showUnselectedLabels: false,
        ),
      ),
      themeMode: ThemeMode.dark,
      debugShowCheckedModeBanner: false,
      initialRoute: '/login',
      routes: {
        '/login': (context) => const LoginScreen(),
        '/signup': (context) => const SignupScreen(),
        '/home': (context) => const HomeScreen(),
        '/search': (context) => const SearchScreen(),
        '/preview': (context) => const PreviewScreen(),
        '/profile': (context) => const ProfileScreen(),
      },
    );
  }
}